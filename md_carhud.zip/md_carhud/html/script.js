$(document).ready(function() {
    window.addEventListener('message', function(event) {
        let data = event.data;

        if (data.type === "ui") {
            if (data.display) {
                $("#container").css("opacity", "1");
            } else {
                $("#container").css("opacity", "0");
            }
        }

        if (data.type === "update") {
            $("#speed").text(data.speed);

            $("#gear").text(data.gear);

            let rpmPercent = data.rpm * 100;
            $("#rpm-bar").css("width", rpmPercent + "%");

            if (data.rpm >= data.redZone) {
                $("#rpm-bar").addClass("redline");
            } else {
                $("#rpm-bar").removeClass("redline");
            }

            let fuelPercent = data.fuel + "%";
            $(".fill-stop-fuel").attr("offset", fuelPercent);
            $(".empty-stop-fuel").attr("offset", fuelPercent);

            let enginePercent = data.engine + "%";
            if (data.engine < 40) {
                $(".fill-stop-engine").attr("stop-color", "#ff3333");
            } else {
                $(".fill-stop-engine").attr("stop-color", "white");
            }
            
            $(".fill-stop-engine").attr("offset", enginePercent);
            $(".empty-stop-engine").attr("offset", enginePercent);
        }
    });
});