Config = {}

Config.UseMPH = true

Config.HideMinimapOnFoot = true

Config.Colors = {
    NormalRPM = "white",
    HighRPM = "#ff3333"
}

Config.RedZoneStart = 0.8