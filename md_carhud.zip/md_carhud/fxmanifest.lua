fx_version 'cerulean'
game 'gta5'

author 'MeDaaa'
version '1.2'
description 'Minimalist style CarHud by MD | discord.gg/Ze4m2Uyxjw'

shared_script 'config.lua'

client_script 'client/client.lua'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
}