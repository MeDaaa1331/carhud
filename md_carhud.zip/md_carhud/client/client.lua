local displayHud = false

local function ToggleRadar(state)
    DisplayRadar(state)
end

CreateThread(function()
    while true do
        local sleep = 200
        local playerPed = PlayerPedId()
        
        if IsPedInAnyVehicle(playerPed, false) then
            sleep = 50
            local vehicle = GetVehiclePedIsIn(playerPed, false)
            
            if vehicle ~= 0 then
                if not displayHud then
                    displayHud = true
                    SendNUIMessage({
                        type = "ui",
                        display = true
                    })
                    if Config.HideMinimapOnFoot then ToggleRadar(true) end
                end

                local speed = GetEntitySpeed(vehicle)
                local currentSpeed = Config.UseMPH and (speed * 2.236936) or (speed * 3.6)
                local rpm = GetVehicleCurrentRpm(vehicle)
                local gear = GetVehicleCurrentGear(vehicle)
                
                if gear == 0 and speed > 0 then gear = "R" end
                if speed == 0 and rpm < 0.2 then gear = "N" end

                local fuel = GetVehicleFuelLevel(vehicle)
                
                local engine = GetVehicleEngineHealth(vehicle) / 10

                SendNUIMessage({
                    type = "update",
                    speed = math.ceil(currentSpeed),
                    rpm = rpm,
                    gear = gear,
                    fuel = fuel,
                    engine = engine,
                    redZone = Config.RedZoneStart
                })
            end
        else
            if displayHud then
                displayHud = false
                SendNUIMessage({
                    type = "ui",
                    display = false
                })
                if Config.HideMinimapOnFoot then ToggleRadar(false) end
            end
        end
        Wait(sleep)
    end
end)